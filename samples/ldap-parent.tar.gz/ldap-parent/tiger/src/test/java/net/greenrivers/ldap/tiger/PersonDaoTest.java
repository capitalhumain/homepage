package net.greenrivers.ldap.tiger;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import org.junit.Test;
import static org.junit.Assert.*;

public class PersonDaoTest {
    private static class SpringContextHolder {
        static ApplicationContext ctx =  new ClassPathXmlApplicationContext( "net/greenrivers/ldap/tiger/appContext.xml" );
    }

    @Test
    public void testGetAll () {
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDao personDAO = (PersonDao) ctx.getBean( "personDao" );
        for( Person p : personDAO.getAll() ) {
            System.out.println( p.getUid() + "/" + p.getUsername() + "/" + p.getEmployeeNumber() );
        }
    }
    
}

package net.greenrivers.ldap.tiger;

import java.util.List;
import org.springframework.ldap.core.simple.SimpleLdapTemplate;
import org.springframework.ldap.core.simple.ParameterizedContextMapper;
import org.springframework.ldap.core.DirContextAdapter;

public class PersonDao {
    private SimpleLdapTemplate simpleLdapTemplate;

    public void setSimpleLdapTemplate(SimpleLdapTemplate simpleLdapTemplate) {
        this.simpleLdapTemplate = simpleLdapTemplate;
    }
    
    public List<Person> getAll () {
        return simpleLdapTemplate.search( "", "(objectclass=person)", 
            new ParameterizedContextMapper<Person>() {
                public Person mapFromContext (Object ctx) {
                    DirContextAdapter adapter = (DirContextAdapter) ctx;
                    Person p = new Person();
                    p.setUsername( adapter.getStringAttribute( "cn" ) );
                    p.setUid( adapter.getStringAttribute( "uid" ) );
                    p.setEmployeeNumber( adapter.getStringAttribute( "employeeNumber" ) );
                    return p;
                } // mapFromContext
            } );
    }
}

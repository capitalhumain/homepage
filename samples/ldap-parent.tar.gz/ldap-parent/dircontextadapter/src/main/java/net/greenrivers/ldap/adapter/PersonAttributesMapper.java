package net.greenrivers.ldap.adapter;

import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.Attribute;
import org.springframework.ldap.core.AttributesMapper;

public class PersonAttributesMapper implements AttributesMapper {
    public Object mapFromAttributes (Attributes attrs) {
        Attribute cn = attrs.get( "cn" );
        Attribute uid = attrs.get( "uid" );
        Attribute en = attrs.get( "employeeNumber" );
        
        Person p = new Person();
        try {
            p.setUid( (String) uid.get() );
            p.setUsername( (String) cn.get() );
            p.setEmployeeNumber( (String) en.get() );
        
            return p;
        } catch(NamingException e) {
            e.printStackTrace();
            return null;
        }
    } // mapFromAttributes
} // PersonAttributesMapper class

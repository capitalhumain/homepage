package net.greenrivers.ldap.adapter;

import org.springframework.ldap.core.support.AbstractContextMapper;
import org.springframework.ldap.core.DirContextOperations;

import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.ContextMapper;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.DistinguishedName;
import org.springframework.ldap.core.DirContextProcessor;

import org.springframework.ldap.core.SearchExecutor;
import org.springframework.ldap.core.CollectingNameClassPairCallbackHandler;
import org.springframework.ldap.core.AttributesMapperCallbackHandler;
import org.springframework.ldap.core.ContextMapperCallbackHandler;

import org.springframework.ldap.control.PagedResult;
import org.springframework.ldap.control.PagedResultsCookie;
import org.springframework.ldap.control.PagedResultsRequestControl;

import org.springframework.ldap.core.ContextExecutor;

import java.util.List;
import javax.naming.Name;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;

public class PersonDaoImpl {
    // 除了 implements ContextMapper，另一個選擇是 extends AbstractContextMapper 。
    public static class PersonContextMapper implements ContextMapper {
        // JavaDoc says Map a single LDAP Context to an object.
        public Object mapFromContext (Object ctx) {
            DirContextAdapter context = (DirContextAdapter) ctx;
            Person p = new Person();
            p.setUsername( context.getStringAttribute( "cn" ) );
            p.setUid( context.getStringAttribute( "uid" ) );
            p.setEmployeeNumber( context.getStringAttribute( "employeeNumber" ) );
            return p;
        } // mapFromContext method
    } // PersonContextMapper class definition
    
    public static class PersonContextMapper2 extends AbstractContextMapper {
        public Object doMapFromContext (DirContextOperations ctx) {
            DirContextAdapter context = (DirContextAdapter) ctx;
            Person p = new Person();
            p.setUsername( context.getStringAttribute( "cn" ) );
            p.setUid( context.getStringAttribute( "uid" ) );
            p.setEmployeeNumber( context.getStringAttribute( "employeeNumber" ) );
            return p;
        } // doMapFromContext method
    } // PersonContextMapper2 class definition
    
    private LdapTemplate ldapTemplate;

    public void setLdapTemplate (LdapTemplate ldapTemplate) {
        this.ldapTemplate = ldapTemplate;
    }
    
    public Person findByPrimaryKey (String uid) {
        Name dn = buildDn( uid );
        // About LdapTemplate#lookup(dn: Name, mapper: ContextMapper)
        // Convenience method to lookup a specified DN and automatically pass the found object to a ContextMapper.
        return (Person) ldapTemplate.lookup( dn, new PersonContextMapper() );
    } // findByPrimaryKey
    
    /**
     * 根據javadoc講DirContext#lookupLink這個method找到的物件根據我們敢給怎樣的distinguished name，甚至有可能拿到null
     **/
    public Object lookupLink( final Name name ) {
        ContextExecutor executor = new ContextExecutor() {
            public Object executeWithContext (DirContext ctx) {
                try {
                    return ctx.lookupLink( name );
                } catch(NamingException e) {
                    e.printStackTrace();
                    return null;
                }
            }
        };
        
        return ldapTemplate.executeReadOnly( executor );
    } // lookupLink
    
    public void create (Person p) {
        Name dn = buildDn( p );
        DirContextAdapter context = new DirContextAdapter( dn );
        
        // before extract method, use this way
        //context.setAttributeValues( "objectclass", new String[] { "top", "organizationalperson", "inetorgperson", "person" } );
        //context.setAttributeValue( "cn", p.getUsername() );
        //context.setAttributeValue( "sn", p.getUsername() );
        //context.setAttributeValue( "uid", p.getUid() );
        //context.setAttributeValue( "userPassword", p.getPassword() );
        //context.setAttributeValue( "employeeNumber", p.getEmployeeNumber() );
        mapToContext( p, context );
        
        ldapTemplate.bind( context );
    } // create
    
    public void update (Person p) {
        Name dn = buildDn( p );
        DirContextOperations context = ldapTemplate.lookupContext( dn );
        mapToContext( p, context );
        ldapTemplate.modifyAttributes( context );
    }
    
    public void delete (Person p) {
        ldapTemplate.unbind( buildDn( p ) );
    } // delete
    
    /**
     * 多筆的狀況, final 的目的是要在inner class使用啊啊啊
     * 這是用AttributesMapper把結果弄成Person物件的方法
     **/
    public List searchResultHandleByAttributesMapper (final Name base, final String filter, final String[] params, final SearchControls ctls) {
        SearchExecutor executor = new SearchExecutor() {
            public NamingEnumeration executeSearch (DirContext ctx) {
                try {
                    return ctx.search( base, filter, params, ctls );
                } catch( NamingException e ) {
                    e.printStackTrace();
                    return null;
                }
            }
        };
        
        // 準備handler
        CollectingNameClassPairCallbackHandler handler = new AttributesMapperCallbackHandler( new PersonAttributesMapper() );
        // 找東西去
        ldapTemplate.search( executor, handler );
        return handler.getList();
    } // searchResultHandleByAttributesMapper
    
    /**
     * 使用DirContextProcessor的版本
     **/
    public List searchResultHandleByAttributesMapper (final Name base, final String filter, final String[] params, final SearchControls ctls, DirContextProcessor processor) {
        SearchExecutor executor = new SearchExecutor() {
            public NamingEnumeration executeSearch (DirContext ctx) {
                try {
                    return ctx.search( base, filter, params, ctls );
                } catch( NamingException e ) {
                    e.printStackTrace();
                    return null;
                }
            }
        };
        
        CollectingNameClassPairCallbackHandler handler = new AttributesMapperCallbackHandler( new PersonAttributesMapper() );
        ldapTemplate.search( executor, handler, processor );    // 不同點
        return handler.getList();
    } // searchResultHandleByAttributesMapper
    
    public List searchResultHandleByContextMapper (final Name base, final String filter, final String[] params, final SearchControls ctls) {
        SearchExecutor executor = new SearchExecutor() {
            public NamingEnumeration executeSearch (DirContext ctx) {
                try {
                    return ctx.search( base, filter, params, ctls );
                } catch( NamingException e ) {
                    e.printStackTrace();
                    return null;
                }
            }
        };
        
        CollectingNameClassPairCallbackHandler handler = new ContextMapperCallbackHandler( new PersonContextMapper() );
        ldapTemplate.search( executor, handler );
        return handler.getList();
    } // searchResultHandleByContextMapper
    
    private static final int PAGE_SIZE = 2;
    
    public PagedResult getAllPersons (PagedResultsCookie cookie) {
        PagedResultsRequestControl control = new PagedResultsRequestControl( PAGE_SIZE, cookie );
        SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope( SearchControls.SUBTREE_SCOPE );
        
        List persons = ldapTemplate.search( "", "objectclass=person", searchControls, new PersonAttributesMapper(), control );
        
        return new PagedResult( persons, control.getCookie() );
    } // getAllPersons
    
    protected void mapToContext (Person p, DirContextOperations context) {
        context.setAttributeValues( "objectclass", new String[] { "top", "organizationalperson", "inetorgperson", "person" } );
        context.setAttributeValue( "cn", p.getUsername() );
        context.setAttributeValue( "sn", p.getUsername() );
        context.setAttributeValue( "uid", p.getUid() );
        context.setAttributeValue( "userPassword", p.getPassword() );
        context.setAttributeValue( "employeeNumber", p.getEmployeeNumber() );
    } // mapToContext
    
    /**
     * build distinguished name from person object
     **/
    protected Name buildDn (Person p) {
        DistinguishedName dn = new DistinguishedName();
        dn.add( "ou", "People" );
        dn.add( "uid", p.getUid() );
        return dn;
    }
    
    /**
     * build distinguished name from uid
     **/
    protected Name buildDn (String uid) {
        DistinguishedName dn = new DistinguishedName();
        dn.add("ou", "People");
        dn.add("uid", uid);
        return dn;
    }
}

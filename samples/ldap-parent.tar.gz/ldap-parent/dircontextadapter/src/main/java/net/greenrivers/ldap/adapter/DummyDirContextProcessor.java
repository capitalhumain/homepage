package net.greenrivers.ldap.adapter;

import org.springframework.ldap.core.DirContextProcessor;

import javax.naming.directory.DirContext;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.Control;
import javax.naming.NamingException;

public class DummyDirContextProcessor implements DirContextProcessor {
    public void preProcess (DirContext ctx) {
        System.out.println( "DummyDirContextProcessor#preProcess called " + ctx );
        /*
        try {
            InitialLdapContext context = (InitialLdapContext) ctx;
            Control[] ctls = context.getConnectControls();
            for( Control control : ctls ) {
                System.out.println( "Control: id=" + control.getID() + ";"  );
            }
        } catch(NamingException e) {
            e.printStackTrace();
        }
        * */
    }
    
    public void postProcess (DirContext ctx) {
        System.out.println( "DummyDirContextProcessor#postProcess called " + ctx );
    }
}

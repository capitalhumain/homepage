package net.greenrivers.ldap.adapter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import org.junit.Test;
import static org.junit.Assert.*;

import org.springframework.ldap.core.DistinguishedName;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.DirContextProcessor;
import org.springframework.ldap.control.PagedResult;
import org.springframework.ldap.control.PagedResultsCookie;

import javax.naming.Name;
import javax.naming.directory.SearchControls;
import java.util.List;

public class PersonDaoTest {
    private static class SpringContextHolder {
        static ApplicationContext ctx =  new ClassPathXmlApplicationContext( "net/greenrivers/ldap/adapter/appContext.xml" );
    }

    @Test
    public void testFindByPrimaryKey () {
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDaoImpl personDAO = (PersonDaoImpl) ctx.getBean( "personDao" );
        
        Person p = personDAO.findByPrimaryKey( "user001" );
        assertNotNull( p );
        assertEquals( p.getUsername(), "Aaccf" );
    }
    
    @Test
    public void testCreate () {
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDaoImpl personDAO = (PersonDaoImpl) ctx.getBean( "personDao" );
        
        Person p = new Person();
        p.setUsername( "test" );
        p.setUid( "user003" );
        p.setEmployeeNumber( "0" );
        p.setPassword( "password" );
        personDAO.create( p );
        
        Person added = personDAO.findByPrimaryKey( "user003" );
        assertNotNull( p );
        assertEquals( p.getUsername(), added.getUsername() );
        
        personDAO.delete( p );
    }
    
    @Test
    public void testUpdate () {
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDaoImpl personDAO = (PersonDaoImpl) ctx.getBean( "personDao" );
        
        Person p = new Person();
        p.setUsername( "test" );
        p.setUid( "user003" );
        p.setEmployeeNumber( "0" );
        p.setPassword( "password" );
        personDAO.create( p );
        
        p.setUsername( "test0" );
        p.setEmployeeNumber( "1" );
        personDAO.update( p );
        
        Person added = personDAO.findByPrimaryKey( "user003" );
        assertNotNull( p );
        assertEquals( "test0", added.getUsername() );
        assertEquals( "1", added.getEmployeeNumber() );
        
        personDAO.delete( p );
    }
    
    @Test
    public void testSearchResultHandleByAttributesMapper() {
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDaoImpl personDAO = (PersonDaoImpl) ctx.getBean( "personDao" );
        
        DistinguishedName dn = new DistinguishedName();
        dn.add("ou", "People");
        
        SearchControls sc = new SearchControls();
        // scope要設對啊
        sc.setSearchScope( SearchControls.ONELEVEL_SCOPE );
        sc.setCountLimit( 100 );
        sc.setTimeLimit( 3000 );
        sc.setReturningAttributes( new String[] {"cn", "uid", "employeeNumber"} );
        sc.setDerefLinkFlag( true );
        sc.setReturningObjFlag( true );
        
        List result = personDAO.searchResultHandleByAttributesMapper( (Name)dn, "(objectClass=person)", new String[] {}, sc );
        assertNotNull( result );
        assertEquals( 5, result.size() );
        for( Object p : result ) {
            Person person = (Person) p;
            System.out.println( person.getUsername() + "/" + person.getUid() );
        }
    }
    
    @Test
    public void testSearchResultHandleByContextMapper() {
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDaoImpl personDAO = (PersonDaoImpl) ctx.getBean( "personDao" );
        
        DistinguishedName dn = new DistinguishedName();
        dn.add("ou", "People");
        
        SearchControls sc = new SearchControls();
        sc.setSearchScope( SearchControls.ONELEVEL_SCOPE );
        sc.setCountLimit( 100 );
        sc.setTimeLimit( 3000 );
        sc.setReturningAttributes( new String[] {"cn", "uid", "employeeNumber"} );
        sc.setDerefLinkFlag( true );
        sc.setReturningObjFlag( true );
        
        List result = personDAO.searchResultHandleByContextMapper( (Name)dn, "(objectClass=person)", new String[] {}, sc );
        assertNotNull( result );
        assertEquals( 5, result.size() );
        for( Object p : result ) {
            Person person = (Person) p;
            System.out.println( person.getUsername() + "/" + person.getUid() );
        }
    }
    
    @Test
    public void testDummyDirContextProcessor() {
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDaoImpl personDAO = (PersonDaoImpl) ctx.getBean( "personDao" );
        
        DistinguishedName dn = new DistinguishedName();
        dn.add("ou", "People");
        
        SearchControls sc = new SearchControls();
        // scope要設對啊
        sc.setSearchScope( SearchControls.ONELEVEL_SCOPE );
        sc.setCountLimit( 100 );
        sc.setTimeLimit( 3000 );
        sc.setReturningAttributes( new String[] {"cn", "uid", "employeeNumber"} );
        sc.setDerefLinkFlag( true );
        sc.setReturningObjFlag( true );
        
        DirContextProcessor processor = new DummyDirContextProcessor();
        
        List result = personDAO.searchResultHandleByAttributesMapper( (Name)dn, "(objectClass=person)", new String[] {}, sc, processor );
        assertNotNull( result );
        assertEquals( 5, result.size() );
        for( Object p : result ) {
            Person person = (Person) p;
            System.out.println( "testDummyDirContextProcessor: " + person.getUsername() + "/" + person.getUid() );
        }
    }
    
    @Test
    public void testLookupLink() {
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDaoImpl personDAO = (PersonDaoImpl) ctx.getBean( "personDao" );
        
        DistinguishedName dn = new DistinguishedName();
        dn.add( "ou", "People" );
        dn.add( "uid", "user001" );
        
        // 這樣的 distinguished name 找到的是 DirContextAdpater object
        Object adapter = personDAO.lookupLink( dn );
        assertNotNull( adapter );
        
        DirContextAdapter context = (DirContextAdapter) adapter;
        Person p = new Person();
        p.setUsername( context.getStringAttribute( "cn" ) );
        p.setUid( context.getStringAttribute( "uid" ) );
        p.setEmployeeNumber( context.getStringAttribute( "employeeNumber" ) );
        assertEquals( "Aaccf", p.getUsername() );
    }
    
    @Test
    public void testLookupLinkReturnNull() {
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDaoImpl personDAO = (PersonDaoImpl) ctx.getBean( "personDao" );
        
        DistinguishedName dn = new DistinguishedName();
        dn.add( "ou", "People" );
        dn.add( "uid", "user9999" );   // user9999應該不在吧 哈哈
        
        Object result = personDAO.lookupLink( dn );
        assertNull( result );
        // 雖然結果如預期，但是不是我想要的執行路線，
        // 應該是在ctx.lookup的時候catch NamingException下來處理的結果
        // javax.naming.NameNotFoundException: 
        // [LDAP: error code 32 - The search base entry 'uid=user9999,ou=People,dc=example,dc=com' does not exist]; 
        // remaining name 'uid=user9999,ou=People'
        // 發生在
        // at javax.naming.InitialContext.lookupLink(InitialContext.java:476)
        // at net.greenrivers.ldap.adapter.PersonDaoImpl$1.executeWithContext(PersonDaoImpl.java:70)
        // 我想看到的是正常執行lookupLink，但是 return null的狀況...偶還是太菜了
    }
    
    @Test
    public void testPagedSearchResults() {
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDaoImpl personDAO = (PersonDaoImpl) ctx.getBean( "personDao" );
        List result = null;
        PagedResultsCookie cookie = null;
        
        // first run
        PagedResult pr = personDAO.getAllPersons( cookie );
        cookie = pr.getCookie();
        result = pr.getResultList();
        assertNotNull( cookie );
        assertEquals( 2, result.size() );
        for( Object p : result ) {
            Person person = (Person) p;
            System.out.println( "Paged 1: " + person.getUid() );
        }
        
        // second run
        pr = personDAO.getAllPersons( cookie );
        cookie = pr.getCookie();
        result = pr.getResultList();
        assertNotNull( cookie );
        assertEquals( 2, result.size() );
        for( Object p : result ) {
            Person person = (Person) p;
            System.out.println( "Paged 2: " + person.getUid() );
        }
    }
}

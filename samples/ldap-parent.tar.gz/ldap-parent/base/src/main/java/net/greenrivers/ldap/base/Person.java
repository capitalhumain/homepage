package net.greenrivers.ldap.base;

public class Person {
    private String username;
    private String uid;
    private String employeeNumber;
    private String password;
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public void setUid(String uid) {
        this.uid = uid;
    }
    
    public void setEmployeeNumber(String employeeNumber) {
        this.employeeNumber = employeeNumber;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getUsername() {
        return username;
    }
    
    public String getUid() {
        return uid;
    }
    
    public String getEmployeeNumber() {
        return employeeNumber;
    }
    
    public String getPassword() {
        return password;
    }
}

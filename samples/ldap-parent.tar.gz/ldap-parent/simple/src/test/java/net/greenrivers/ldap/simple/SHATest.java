package net.greenrivers.ldap.simple;

import org.junit.Test;
import static org.junit.Assert.*;

public class SHATest {
    @Test
    public void testEncode() {
        System.out.println( SHA.encode( "password" ) );
    }
    
    @Test 
    public void testMakeLDAPEncodeString() {
        final String result = SHA.makeLDAPEncodeString( "password" );
        final String encoded = SHA.encode( "password" );
        final String head = result.substring( 0, 5 );
        final String body = result.substring( 5 );
        
        System.out.println( result );
        System.out.println( head );
        System.out.println( body );
        assertEquals( "{SHA}", head );
        assertEquals( encoded, body );
    }
}

package net.greenrivers.ldap.simple;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import org.junit.Test;
import static org.junit.Assert.*;

public class PersonDaoTest {
    private static class SpringContextHolder {
        static ApplicationContext ctx =  new ClassPathXmlApplicationContext( "net/greenrivers/ldap/simple/appContext.xml" );
    }

    @Test
    public void testGetAllPersonName() {
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDaoImpl personDAO = (PersonDaoImpl) ctx.getBean( "personDao" );
        for( Object name : personDAO.getAllPersonNames() ) {
            System.out.println( name );
        }
    }
    
    @Test
    public void testCreate() {
        Person p = new Person();
        p.setUsername( "test" );
        p.setUid( "user003" );
        p.setEmployeeNumber( "0" );
        // 其實不用雞婆加密勒....
        // p.setPassword( SHA.makeLDAPEncodeString( "password" ) );
        p.setPassword( "password" );
        
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDaoImpl personDAO = (PersonDaoImpl) ctx.getBean( "personDao" );
        
        personDAO.create( p );
    }
    
    @Test
    public void testUpdate() {
        Person p = new Person();
        p.setUsername( "test1" );
        p.setUid( "user003" );
        // 把setEmployeeNumber comment掉看看會不會不見 
        // => org.springframework.ldap.InvalidAttributeValueException: 'employeeNumber' has no values.; nested exception is javax.naming.directory.InvalidAttributeValueException: 'employeeNumber' has no values.; remaining name 'uid=user003,ou=People'
        p.setEmployeeNumber( "1" );
        p.setPassword( "password" );
        
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDaoImpl personDAO = (PersonDaoImpl) ctx.getBean( "personDao" );
        
        personDAO.update( p );
    }
    
    @Test
    public void testUpdateNotExistUser() {
        Person p = new Person();
        p.setUsername( "test1" );
        p.setUid( "user003a" );
        // 把setEmployeeNumber comment掉看看會不會不見 
        // => org.springframework.ldap.InvalidAttributeValueException: 'employeeNumber' has no values.; nested exception is javax.naming.directory.InvalidAttributeValueException: 'employeeNumber' has no values.; remaining name 'uid=user003,ou=People'
        p.setEmployeeNumber( "1" );
        p.setPassword( "password" );
        
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDaoImpl personDAO = (PersonDaoImpl) ctx.getBean( "personDao" );
        
        personDAO.update( p );
        
        // 會搞進去
        personDAO.delete( p );
    }
    
    @Test
    public void testUpdateEmployeeNumber() {
        Person p = new Person();
        // 不會被改到
        p.setUsername( "test2" );
        p.setUid( "user003" );
        p.setEmployeeNumber( "0" );
        // 不會被改到
        p.setPassword( "password1" );
        
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDaoImpl personDAO = (PersonDaoImpl) ctx.getBean( "personDao" );
        
        personDAO.modifyEmployeeNumber( p );
    }
    
    @Test
    public void testDelete() {
        Person p = new Person();
        p.setUsername( "test2" );
        // 故意給錯也不會跟你說她砍不到東西勒 真是讚
        // p.setUid( "user003a" );
        p.setUid( "user003" );
        p.setEmployeeNumber( "55" );
        p.setPassword( "password1" );
        
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDaoImpl personDAO = (PersonDaoImpl) ctx.getBean( "personDao" );
        
        personDAO.delete( p );
    }
}

package net.greenrivers.ldap.simple;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.binary.Base64;

public final class SHA {
    public static final String DIGEST_NAME = "SHA";
    
    public static String makeLDAPEncodeString(String input) {
        if( null == input ) {
            throw new IllegalArgumentException( "input can not be null!!" );
        } // password null check
        StringBuffer result = new StringBuffer();
        String encoded = encode( input );
        if( null == encoded ) {
            // DIGEST_NAME not support
            return result.toString();
        } else {
            result.append( "{" ).append( DIGEST_NAME ).append( "}" ).append( encoded );
            return result.toString();
        } // if
    } // makeUserPasswordString()
    
    /**
     * return Base64( SHA( password ) )
     **/
    public static String encode(String input) {
        if( null == input ) {
            throw new IllegalArgumentException( "input can not be null!!" );
        } // password null check
        try {
            MessageDigest md = MessageDigest.getInstance( DIGEST_NAME );
            md.update( input.getBytes() );
            
            byte byteData[] = md.digest();
            
            /*
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < byteData.length; i++) {
                sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
            }
            
            return sb.toString();
            */
            return Base64.encodeBase64String( byteData );
        } catch ( NoSuchAlgorithmException e ) {
        }
        return null;
    } // encode()
}

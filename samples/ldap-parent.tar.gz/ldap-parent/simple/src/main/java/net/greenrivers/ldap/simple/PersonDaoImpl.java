package net.greenrivers.ldap.simple;

import java.util.List;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.NamingException;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.DistinguishedName;
import javax.naming.Name;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.DirContext;
import javax.naming.directory.Attribute;

public class PersonDaoImpl {
    public static final String BASE_DN = "dc=example,dc=com";
    
    private LdapTemplate ldapTemplate;

    public void setLdapTemplate(LdapTemplate ldapTemplate) {
        this.ldapTemplate = ldapTemplate;
    }
    
    public List getAllPersonNames() {
        return ldapTemplate.search( "", "(&(objectclass=person)(employeeNumber=0))",
            new AttributesMapper() {
                public Object mapFromAttributes(Attributes attrs) throws NamingException {
                    return attrs.get("cn").get();
                }
            } );
    }
    
    /**
     * bind to ldap
     **/
    public void create(Person p) {
        Name dn = buildDn(p);
        ldapTemplate.bind(dn, null, buildAttributes(p));
    }
    
    /**
     * update by rebind to ldap
     * all attribute should provide
     **/
    public void update(Person p) {
        Name dn = buildDn(p);
        ldapTemplate.rebind(dn, null, buildAttributes(p));
    }
    
    /**
     * update employeeNumber by modifyAttributes
     * 只會改你叫她改得，這才是乖孩子
     **/
    public void modifyEmployeeNumber(Person p) {
        Name dn = buildDn( p );
        Attribute attr = new BasicAttribute( "employeeNumber", p.getEmployeeNumber() );
        ModificationItem item = new ModificationItem( DirContext.REPLACE_ATTRIBUTE, attr );
        ldapTemplate.modifyAttributes( dn, new ModificationItem[] { item } );
    }
    
    /**
     * delete (unbind)
     **/
    public void delete(Person p) {
        Name dn = buildDn( p );
        ldapTemplate.unbind( dn );
    }
    
    protected Name buildDn(Person p) {
        // 這個不用喔 因為contextSource有設他會加進去
        // 按照範例加了會爆掉
        //DistinguishedName dn = new DistinguishedName(BASE_DN);
        DistinguishedName dn = new DistinguishedName();
        dn.add("ou", "People");
        dn.add("uid", p.getUid());
        return dn;
    }
    
    private Attributes buildAttributes(Person p) {
        Attributes attrs = new BasicAttributes();
        BasicAttribute ocattr = new BasicAttribute("objectclass");
        ocattr.add("top");
        ocattr.add("organizationalperson");
        ocattr.add("inetorgperson");
        ocattr.add("person");
        
        attrs.put(ocattr);
        attrs.put("cn", p.getUsername());
        attrs.put("sn", p.getUsername());
        attrs.put("uid", p.getUid());
        attrs.put("userPassword", p.getPassword());
        attrs.put("employeeNumber", p.getEmployeeNumber());
        return attrs;
   }
}

package net.greenrivers.ldap.transaction;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import net.greenrivers.ldap.transaction.domain.Person;

import org.junit.Test;
import static org.junit.Assert.*;

public class PersonDaoTest {
    private static class SpringContextHolder {
        static ApplicationContext ctx =  new ClassPathXmlApplicationContext( "net/greenrivers/ldap/transaction/appContext.xml" );
    }

    @Test
    public void testUpdate() {
        Person p = new Person();
        p.setUsername( "test1" );
        p.setUid( "user010" );
        p.setEmployeeNumber( "1" );
        p.setPassword( "password" );
        
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDao personDAO = (PersonDao) ctx.getBean( "personDao" );
        
        personDAO.update( p );
    }
    
    @Test
    public void testNoTxUpdate() {
        Person p = new Person();
        p.setUsername( "test1" );
        p.setUid( "user010" );
        p.setEmployeeNumber( "1" );
        p.setPassword( "password" );
        
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDao personDAO = (PersonDao) ctx.getBean( "personDaoNoTx" );
        
        personDAO.update( p );
    }
    
    @Test 
    public void testUpdateFailed() {
        Person p = new Person();
        p.setUsername( "test1" );
        p.setUid( "user010" );
        p.setEmployeeNumber( "1" );
        p.setPassword( "password" );
        
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDao personDAO = (PersonDao) ctx.getBean( "personDao" );
        
        try {
            personDAO.updateBad( p );
            fail( "Should not be here" );
        } catch (RuntimeException e) {
            // good
        }
    }
    
    @Test
    public void testDelete() {
        Person p = new Person();
        p.setUsername( "dummy" );
        p.setUid( "dummy" );
        p.setEmployeeNumber( "1" );
        p.setPassword( "password" );
        
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDao personDAO = (PersonDao) ctx.getBean( "personDaoNoTx" );
        
        personDAO.create( p );
        
        personDAO.delete( p );
    }
    
    @Test
    public void testRenamingStrategy() {
        Person p = new Person();
        p.setUsername( "test1" );
        p.setUid( "user010" );
        p.setEmployeeNumber( "1" );
        p.setPassword( "password" );
        
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDao personDAO = (PersonDao) ctx.getBean( "personDao2" );
        
        personDAO.update( p );
    }
}

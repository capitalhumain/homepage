package net.greenrivers.ldap.pooling;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import org.junit.Test;
import static org.junit.Assert.*;

public class PersonDaoTest {
    private static class SpringContextHolder {
        static ApplicationContext ctx =  new ClassPathXmlApplicationContext( "net/greenrivers/ldap/pooling/appContext.xml" );
    }

    @Test
    public void testGetAllPersonName () {
        ApplicationContext ctx = SpringContextHolder.ctx;
        PersonDao personDAO = (PersonDao) ctx.getBean( "personDao" );
        for( Object name : personDAO.getAllPersonNames() ) {
            System.out.println( name );
        }
    }
}

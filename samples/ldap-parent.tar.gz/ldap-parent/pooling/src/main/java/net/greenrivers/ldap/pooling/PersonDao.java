package net.greenrivers.ldap.pooling;

import org.springframework.ldap.core.support.BaseLdapPathAware;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.DistinguishedName;

import java.util.List;
import javax.naming.directory.Attributes;
import javax.naming.NamingException;

public class PersonDao implements BaseLdapPathAware {
    private DistinguishedName basePath;
    private LdapTemplate ldapTemplate;

    public void setLdapTemplate (LdapTemplate ldapTemplate) {
        this.ldapTemplate = ldapTemplate;
    }

    public void setBaseLdapPath (DistinguishedName basePath) {
        this.basePath = basePath;
    }
    
    public List getAllPersonNames() {
        System.out.println( basePath );
        return ldapTemplate.search( "", "(&(objectclass=person)(employeeNumber=0))",
            new AttributesMapper() {
                public Object mapFromAttributes(Attributes attrs) throws NamingException {
                    return attrs.get("cn").get();
                }
            } );
    }
}

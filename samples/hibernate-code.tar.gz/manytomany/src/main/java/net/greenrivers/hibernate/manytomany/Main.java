package org.greenrivers.hibernate.manytomany;

public class Main {
    public static void main(String[] args) {
    }
}
